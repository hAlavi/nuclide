# Swift language support in Atom

Adds syntax highlighting to Swift files in Atom.

**NOTE**: I am currently looking for a new maintainer for this package.
