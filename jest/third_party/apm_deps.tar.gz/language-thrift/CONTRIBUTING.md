## Contributing

Once you've made your great commits:

1. [Fork][forking] the repository
2. Create a feature branch
3. Write your code (and tests please)
4. Push to your branch's origin
5. Create a [Pull Request][pull requests] from your branch
6. That's it!

[forking]: http://help.github.com/forking/
[pull requests]: http://help.github.com/pull-requests/
